import Test
import Testt


def print_hi(name):
    # Use a breakpoint in the code line below to debug your script.
    print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi('PyCharm')
    Test.UnitTest_Assignment().test_positive()
    Test.UnitTest_Assignment().test_positiveForGreater()
    Test.UnitTest_Assignment().test_negative()
    Test.UnitTest_Assignment().test_file_not_found()